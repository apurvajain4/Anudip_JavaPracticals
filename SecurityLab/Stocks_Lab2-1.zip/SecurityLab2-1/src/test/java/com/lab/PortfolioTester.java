package com.lab;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class PortfolioTester {
	@Mock
	private StockService stockService;

	@Test
	void testGetMarketValue() {
		List<Stock> stocks = new ArrayList<>();
		Stock sbi = new Stock("sbi1", "SBI", 15);
		Stock tcs = new Stock("tcs1", "TCS", 5);
		stocks.add(sbi);
		stocks.add(tcs);
		when(stockService.getPrice(sbi)).thenReturn(838.85);
		when(stockService.getPrice(tcs)).thenReturn(3837.00);
		Portfolio portfolio = new Portfolio();
		portfolio.setStocks(stocks);
		portfolio.setStockService(stockService);
		double marketValue = portfolio.getMarketValue();
		assertEquals(4000.00, marketValue);
//		assertEquals(31767.75, marketValue);
	}
}