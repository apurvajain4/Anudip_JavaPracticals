package com.lab;

import java.util.ArrayList;
import java.util.List;

public class Portfolio {
	private StockService stockService;
	private List<Stock> stocks;

	public Portfolio() {
		this.stocks = new ArrayList<>();
	}

	public StockService getStockService() {
		return stockService;
	}

	public void setStockService(StockService stockService) {
		this.stockService = stockService;
	}

	public List<Stock> getStocks() {
		return stocks;
	}

	public void setStocks(List<Stock> stocks) {
		this.stocks = stocks;
	}

	public double getMarketValue() {
		double totalValue = 0;

		for (Stock stock : stocks) {
			totalValue += stock.getQuantity() * stockService.getPrice(stock);
		}
		return totalValue;
	}
}