package com.lab;

public interface StockService {
	public double getPrice(Stock stock);
}