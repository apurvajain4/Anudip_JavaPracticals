package com.lab;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class MathOperationTest {
	@Mock
	private ScientificCalculatorService scientificCalculatorService;
	@InjectMocks
	private MathOperation mathOperation;

	@Test
	public void testXToThePowerY() {
		// Given
		when(scientificCalculatorService.xToThePowerY(2, 3)).thenReturn(8.0);
		// When
		double result = mathOperation.xToThePowerY(2, 3);
		// Then
		assertEquals(8.0, result);
		verify(scientificCalculatorService).xToThePowerY(2, 3);
	}
}