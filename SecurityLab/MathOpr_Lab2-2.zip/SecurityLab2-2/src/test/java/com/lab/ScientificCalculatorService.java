package com.lab;

public interface ScientificCalculatorService {
	double xToThePowerY(double input1, double input2);
}