package com.lab;

public class MathOperation {
	private ScientificCalculatorService sciCalcService;

	public MathOperation(ScientificCalculatorService sciCalcService) {
		this.sciCalcService = sciCalcService;
	}

	public double xToThePowerY(double input1, double input2) {
		return sciCalcService.xToThePowerY(input1, input2);
	}
}